# ovs_bridge
- create openvswitch bridges and tagged vlans without accessing your machine manually!
- only a single physical NIC is required and you wont break ssh connection!
- ji_podhead.ovs_bridge will apply your settings, wait for your machine to reboot with the applied configuration 
- fully automated, so you can continue using those vlans and without accessing the machines/hosts manually
- ji_podhead.ovs_bridge will also create a libvirt Virtual Network for you 
- isolate your wm traffic using ansible, ovs bridges and vlans 
- create your vlans and  virtual machines with a single playbook

# MORE IS COMMING SOON
